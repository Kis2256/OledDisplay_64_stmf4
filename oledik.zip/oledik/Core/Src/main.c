// /Simple code written for 128x64 display and under the use of stm32f4\ by Kis
// The authors of the original libraries are listed in them

#include "stm32f4xx_hal.h"
#include "ssd1306.h"
#include "horse_anim.h"

I2C_HandleTypeDef hi2c1;

// The I2C interface
void I2C1_Init(void) {
    hi2c1.Instance = I2C1;
    hi2c1.Init.ClockSpeed = 400000; // 4kHz
    hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
    hi2c1.Init.OwnAddress1 = 0;
    hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2 = 0;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;

    HAL_I2C_Init(&hi2c1);
}
// Function for display's properties ( you can change code there and see what change xD )
void displayFrame(const unsigned char *frame) {
    ssd1306_Fill(Black);
    int xOffset = 32;
    int yOffset = 0;
    for (int y = 0; y < 16; y++) {
        for (int x = 0; x < 16; x++) {
            unsigned char pixel = frame[(y * 64) + x]; //frame
            // Draw a 4x4 block for any pixel
            for (int dy = 0; dy < 4; dy++) {
                for (int dx = 0; dx < 16; dx++) {
                    ssd1306_DrawPixel(xOffset + x * 4 + dx, yOffset + y * 4 + dy, pixel ? White : Black);
                }
            }
        }
    }
    ssd1306_UpdateScreen(&hi2c1);
}

const unsigned char *animationFrames[] = {horse1, horse2, horse3,horse4, horse5, horse6, horse7, horse8};
const int numFrames = sizeof(animationFrames) / sizeof(animationFrames[0]);
// Function for animation
void animateHorse(void) {
    int frameIndex = 0;
    while (1) {
        displayFrame(animationFrames[frameIndex]);
        frameIndex = (frameIndex + 1) % numFrames;
        HAL_Delay(10); // Speed
    }
}

int main(void) {
    HAL_Init();
    I2C1_Init();
    ssd1306_Init(&hi2c1);

    // Run animation
    animateHorse();

}
